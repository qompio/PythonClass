# ---------------------------------------------------------- #
# Title: Listing 04
# Description: A script module that should be run as "Main"
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# ---------------------------------------------------------- #
if __name__ == "__main__":
    import DataProcessor, Employees
else:
    raise Exception("This file was not created to be imported")
