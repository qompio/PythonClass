# ---------------------------------------------------------- #
# Title: Listing 05
# Description: A script module that should not run as "Main"
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# ---------------------------------------------------------- #
if __name__ == "__main__":
    raise Exception("This file is not meant to ran by itself")

