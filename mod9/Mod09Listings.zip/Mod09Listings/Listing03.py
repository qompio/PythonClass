# ---------------------------------------------------------- #
# Title: Listing03
# Description: A script that runs as the "Main" module
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# ---------------------------------------------------------- #
print(__name__)
if __name__ == "__main__":
    print("This file is the starting point of my program!")
