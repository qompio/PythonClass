# ---------------------------------------------------------- #
# Title: Listing01
# Description: Common components of a Windowed UI
# ChangeLog (Who,When,What):
# RRoot,1.1.2030,Created started script
# ---------------------------------------------------------- #
import tkinter as tk

application_window = tk.Tk()  # creates a root node
application_window.mainloop()  # displays window UI
